/** Automatically generated file. DO NOT MODIFY */
package br.com.k19.cap06;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}